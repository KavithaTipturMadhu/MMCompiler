#include<vector>
#include<string>
#include<list>
#include<map>
#include <algorithm>
#include <sstream>
using namespace std;
#include "llvm/IR/Instructions.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/IR/User.h"
#include "llvm/Pass.h"
#include "llvm/IR/Value.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Module.h"
#include "llvm/Support/raw_ostream.h"
using namespace llvm;

#define DEBUG_TYPE "HyperOpCreationPass"

/**
 * Pass to create HyperOps
 */
struct HyperOpCreationPass: public ModulePass {
	static char ID; // Pass identification, replacement for typeid
	const unsigned int FRAME_SIZE = 16;

	HyperOpCreationPass() :
			ModulePass(ID) {
	}

	//Size of each entry of arguments list in terms of the number of integer registers occupied
	static unsigned int sizeOfArgumentList(list<Value*> arguments) {
		unsigned int argSize = 0;
		for (list<Value*>::iterator argItr = arguments.begin(); argItr != arguments.end(); argItr++) {
			switch ((*argItr)->getType()->getTypeID()) {
			case Type::VoidTyID:
				argSize += 0;
				break;
			case Type::HalfTyID:
				//Treated as single precision floating point
			case Type::FloatTyID:
			case Type::IntegerTyID:
				argSize += 1;
				break;
				//All these types are treated as references in REDEFINE
			case Type::StructTyID:
			case Type::ArrayTyID:
			case Type::PointerTyID:
			case Type::VectorTyID:     ///< 15: SIMD 'packed' format, or other vector type
			case Type::DoubleTyID:
				argSize += 2;
				break;
			default:
				argSize += 0;
				break;
			}
		}
		return argSize;
	}

	virtual bool runOnModule(Module &M) {
		LLVMContext & ctxt = M.getContext();
		list<Function*> addedFunctions;
		int bbIndex = 0;
		map<Value*, Value*> originalToClonedInstrMap;
		list<Function*> originalFunctionList;
		NamedMDNode * annotationsNode = M.getOrInsertNamedMetadata(REDEFINE_ANNOTATIONS);
		for (Module::iterator funcItr = M.begin(); funcItr != M.end() && find(addedFunctions.begin(), addedFunctions.end(), funcItr) == addedFunctions.end(); funcItr++) {
			originalFunctionList.push_back(funcItr);
			StringRef name = funcItr->begin()->getName();
			list<Value*> regArguments;
			list<Value*> valArguments;
			Function::iterator bbItr = funcItr->begin();
			list<BasicBlock*> accumulatedBasicBlocks;
			list<Value*> localDefinitions;
			bool endOfHyperOp = false;
			int i = 1;
			for (Function::arg_iterator argItr = funcItr->arg_begin(); argItr != funcItr->arg_end(); argItr++) {
				//Add function arguments as definitions initially
				funcItr->addAttribute(i++, Attribute::InReg);
				regArguments.push_back(argItr);
			}
			while (bbItr != funcItr->end()) {
				accumulatedBasicBlocks.push_back(bbItr);
				for (BasicBlock::iterator instrItr = bbItr->begin(); instrItr != bbItr->end(); instrItr++) {
					if (isa<LoadInst>(instrItr)) {
						//Check if load is from one of the value arguments of the function
						Value* allocOperand = instrItr->getOperand(0);
						//Is a load from one of the input arguments of the function
						if (isa<AllocaInst>(allocOperand) && find(regArguments.begin(), regArguments.end(), ((Instruction*) allocOperand)->getOperand(0)) != regArguments.end()) {
							continue;
						}
						localDefinitions.push_back(instrItr);
					} else if (isa<CallInst>(instrItr) || isa<InvokeInst>(instrItr)) {
						stringstream firstBBName(NEW_NAME);
						firstBBName << bbIndex;
						bbIndex++;
						BasicBlock* newFunctionCallBlock = bbItr->splitBasicBlock(instrItr, firstBBName.str());
						Instruction* instructionAfterCall = newFunctionCallBlock->begin()->getNextNode();
						stringstream secondBBName(NEW_NAME);
						secondBBName << bbIndex;
						bbIndex++;
						newFunctionCallBlock->splitBasicBlock(instructionAfterCall, secondBBName.str());
						endOfHyperOp = true;
						break;
					} else if (!(isa<AllocaInst>(instrItr) || isa<ReturnInst>(instrItr) || isa<StoreInst>(instrItr))) {
						list<Value*> newArguments;
						for (unsigned int i = 0; i < instrItr->getNumOperands(); i++) {
							Value * argument = instrItr->getOperand(i);
							bool isArgumentLocallyDefined = false, isFunctionArgument = false;
							for (list<Value*>::iterator localDefItr = localDefinitions.begin(); localDefItr != localDefinitions.end(); localDefItr++) {
								bool localDef = false;
								for (Value::use_iterator useItr = (*localDefItr)->use_begin(); useItr != (*localDefItr)->use_end(); useItr++) {
									//Check that the instruction indeed uses the definition and the argument matches the definition
									if ((*useItr) == instrItr && argument == (*localDefItr)) {
										localDef = true;
										break;
									}
								}
								if (localDef) {
									isArgumentLocallyDefined = true;
									break;
								}
							}

							for (list<Value*>::iterator hyperOpArg = regArguments.begin(); hyperOpArg != regArguments.end(); hyperOpArg++) {
								bool functionArgument = false;
								for (Value::use_iterator useItr = (*hyperOpArg)->use_begin(); useItr != (*hyperOpArg)->use_end(); useItr++) {
									if ((*useItr) == instrItr && argument == (*hyperOpArg)) {
										functionArgument = true;
										break;
									}
								}

								if (functionArgument) {
									isFunctionArgument = true;
									break;
								}
							}

							if (!(isArgumentLocallyDefined || isFunctionArgument)) {
								newArguments.push_back(argument);
							}
						}

						if (sizeOfArgumentList(newArguments) + sizeOfArgumentList(regArguments) >= FRAME_SIZE) {
							stringstream newString;
							newString << instrItr->getParent()->getName().str();
							newString << bbIndex;
							bbIndex++;
							bbItr->splitBasicBlock(instrItr, newString.str());
							endOfHyperOp = true;
							break;
						} else {
							regArguments.splice(regArguments.end(), newArguments);
							localDefinitions.push_back(instrItr);
							//Add produces/predicates statement from the sourceHyperOp
							for(list<Value*>::iterator addedArgItr = newArguments.begin();addedArgItr!=newArguments.end();addedArgItr++){
								Value* addedArg = *addedArgItr;


							}

						}
					}
				}

				if (endOfHyperOp) {
					vector<Type*> argsList;
					for (list<Value*>::iterator argumentItr = regArguments.begin(); argumentItr != regArguments.end(); argumentItr++) {
						Value* argument = *argumentItr;
						argsList.push_back(argument->getType());
					}
					ArrayRef<Type*> dataTypes(argsList);

					FunctionType *FT = FunctionType::get(Type::getVoidTy(getGlobalContext()), dataTypes, false);
					Function *newFunction = Function::Create(FT, Function::ExternalLinkage, name, &M);

					//Add metadata to label the function as a HyperOp
					MDString *hyperOpLabel = MDString::get(ctxt, HYPEROP);
					Value * values[2];
					values[0] = hyperOpLabel;
					values[1] = newFunction;
					MDNode *funcAnnotation = MDNode::get(ctxt, values);
					annotationsNode->addOperand(funcAnnotation);

					for (int i = 1; i <= regArguments.size(); i++) {
						newFunction->addAttribute(i, Attribute::InReg);
					}
					for (list<BasicBlock*>::iterator accumulatedBBItr = accumulatedBasicBlocks.begin(); accumulatedBBItr != accumulatedBasicBlocks.end(); accumulatedBBItr++) {
						BasicBlock *newBB = BasicBlock::Create(getGlobalContext(), (*accumulatedBBItr)->getName(), newFunction);
						for (BasicBlock::iterator instrItr = (*accumulatedBBItr)->begin(); instrItr != (*accumulatedBBItr)->end(); instrItr++) {
							Instruction* cloneInstr = instrItr->clone();
							Instruction * originalInstruction = &*instrItr;
							originalToClonedInstrMap.insert(std::make_pair(originalInstruction, cloneInstr));
							if (!isa<AllocaInst>(cloneInstr)) {
								for (int argIndex = 0; argIndex < instrItr->getNumOperands(); argIndex++) {
									Value* argumentToBeUpdated = 0;
									int funcArgIndex = 0;
									for (list<Value*>::iterator argumentItr = regArguments.begin(); argumentItr != regArguments.end(); argumentItr++) {
										if ((*argumentItr) == instrItr->getOperand(funcArgIndex)) {
											argumentToBeUpdated = *argumentItr;
											break;
										}
										funcArgIndex++;
									}

									if (argumentToBeUpdated != 0) {
										cloneInstr->setOperand(argIndex, argumentToBeUpdated);
									}
								}
							}

							//Propagate the instruction as Value* to all those places that use the instruction
							for (Value::use_iterator useItr = instrItr->use_begin(); useItr != instrItr->use_end(); useItr++) {
								bool hasUseInHyperOp = false;
								//Find out if the use is in the same HyperOp
								for (list<BasicBlock*>::iterator useBBItr = accumulatedBasicBlocks.begin(); useBBItr != accumulatedBasicBlocks.end(); useBBItr++) {
									for (BasicBlock::iterator useInstrItr = (*useBBItr)->begin(); useInstrItr != (*useBBItr)->end(); useInstrItr++) {
										if (*useItr == useInstrItr) {
											//Found use in one of the instructions of the HyperOp
											hasUseInHyperOp = true;
											break;
										}
									}
									if (hasUseInHyperOp) {
										break;
									}
								}

								if (hasUseInHyperOp) {
									//Find clone of useInstruction
									if (originalToClonedInstrMap.find(*useItr) != originalToClonedInstrMap.end()) {
										Instruction * originalUseInstruction = (Instruction*) originalToClonedInstrMap.find(*useItr)->first;
										Instruction * createdUseInstruction = (Instruction*) originalToClonedInstrMap.find(*useItr)->second;
										for (int i = 0; i < originalUseInstruction->getNumOperands(); i++) {
											if (originalUseInstruction->getOperand(i) == originalInstruction) {
												createdUseInstruction->setOperand(i, (Value*) cloneInstr);
											}
										}

									}

								}
							}
							newBB->getInstList().insert(newBB->getFirstInsertionPt(), cloneInstr);
						}
					}
					accumulatedBasicBlocks.clear();
					localDefinitions.clear();
					regArguments.clear();
					endOfHyperOp = false;
					addedFunctions.push_back(newFunction);
				}
				bbItr = bbItr->getNextNode();
			}

			if (!accumulatedBasicBlocks.empty()) {
				vector<Type*> argsList;
				for (list<Value*>::iterator argumentItr = regArguments.begin(); argumentItr != regArguments.end(); argumentItr++) {
					Value* argument = *argumentItr;
					argsList.push_back(argument->getType());
				}
				ArrayRef<Type*> dataTypes(argsList);

				FunctionType *FT = FunctionType::get(Type::getVoidTy(getGlobalContext()), dataTypes, false);
				Function *newFunction = Function::Create(FT, Function::ExternalLinkage, name, &M);
				addedFunctions.push_back(newFunction);
				//Add metadata to label the function as a HyperOp
				MDString *hyperOpLabel = MDString::get(ctxt, HYPEROP);
				Value * values[2];
				values[0] = hyperOpLabel;
				values[1] = newFunction;
				MDNode *funcAnnotation = MDNode::get(ctxt, values);
				annotationsNode->addOperand(funcAnnotation);

				for (int i = 1; i <= regArguments.size(); i++) {
					newFunction->addAttribute(i, Attribute::InReg);
				}

				for (list<BasicBlock*>::iterator accumulatedBBItr = accumulatedBasicBlocks.begin(); accumulatedBBItr != accumulatedBasicBlocks.end(); accumulatedBBItr++) {
					BasicBlock *newBB = BasicBlock::Create(getGlobalContext(), (*accumulatedBBItr)->getName(), newFunction);
					for (BasicBlock::reverse_iterator instrItr = (*accumulatedBBItr)->rbegin(); instrItr != (*accumulatedBBItr)->rend(); instrItr++) {
						Instruction* clonedInstr = instrItr->clone();
						Instruction * originalInstruction = &*instrItr;
						originalToClonedInstrMap.insert(std::make_pair(originalInstruction, clonedInstr));
						if (!isa<AllocaInst>(clonedInstr)) {
							for (int argIndex = 0; argIndex < clonedInstr->getNumOperands(); argIndex++) {
								Value* argumentToBeUpdated = 0;
								for (list<Value*>::iterator argumentItr = regArguments.begin(); argumentItr != regArguments.end(); argumentItr++) {
									if ((*argumentItr) == instrItr->getOperand(argIndex)) {
										argumentToBeUpdated = 0;
										//Get Value* of the newly created function
										for (Function::arg_iterator argItr = newFunction->arg_begin(); argItr != newFunction->arg_end(); argItr++) {
											if ((*argItr).getArgNo() == argIndex) {
												argumentToBeUpdated = argItr;
												break;
											}
										}
										if (argumentToBeUpdated != 0) {
											break;
										}
									}
								}

								if (argumentToBeUpdated != 0) {
									clonedInstr->setOperand(argIndex, argumentToBeUpdated);
								}
							}
						}

						//Propogate the instruction as Value* to all those places that use the instruction
						for (Value::use_iterator useItr = instrItr->use_begin(); useItr != instrItr->use_end(); useItr++) {
							bool hasUseInHyperOp = false;
							//Find out if the use is in the same HyperOp
							for (list<BasicBlock*>::iterator useBBItr = accumulatedBasicBlocks.begin(); useBBItr != accumulatedBasicBlocks.end(); useBBItr++) {
								for (BasicBlock::iterator useInstrItr = (*useBBItr)->begin(); useInstrItr != (*useBBItr)->end(); useInstrItr++) {
									if (*useItr == useInstrItr) {
										//Found use in one of the instructions of the HyperOp
										hasUseInHyperOp = true;
										break;
									}
								}
								if (hasUseInHyperOp) {
									break;
								}
							}

							if (hasUseInHyperOp) {
								//Find clone of useInstruction
								if (originalToClonedInstrMap.find(*useItr) != originalToClonedInstrMap.end()) {
									Instruction * originalUseInstruction = (Instruction*) originalToClonedInstrMap.find(*useItr)->first;
									Instruction * clonedUseInstruction = (Instruction*) originalToClonedInstrMap.find(*useItr)->second;
									for (int i = 0; i < originalUseInstruction->getNumOperands(); i++) {
										if (originalUseInstruction->getOperand(i) == originalInstruction) {
											clonedUseInstruction->setOperand(i, (Value*) clonedInstr);
										}
									}

								}

							}
						}

						newBB->getInstList().insert(newBB->getFirstInsertionPt(), clonedInstr);
					}
				}
				accumulatedBasicBlocks.clear();
				localDefinitions.clear();
				regArguments.clear();
				endOfHyperOp = false;
			}
		}

		for (list<Function*>::iterator originalFuncItr = originalFunctionList.begin(); originalFuncItr != originalFunctionList.end(); originalFuncItr++) {
			(*originalFuncItr)->eraseFromParent();
		}
		return true;
	}

private:
	static const char* HYPEROP = "HyperOp";
	static const char* NEW_NAME = "newName";
	static const char* REDEFINE_ANNOTATIONS = "redefine.annotations";
}
;

char HyperOpCreationPass::ID = 2;
static RegisterPass<HyperOpCreationPass> X("HyperOpCreationPass", "Pass to create HyperOps");

