#include <stdio.h>

int main()
{
	int a,b,c;
	a=10;
	b=20;
	while(c>0){
		if(b==20){
			a=10;	
		}
		c=a;
	}
	return 1;
	
}
