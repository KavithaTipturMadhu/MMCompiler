#include <stdio.h>

int main()
{
	int c=10;
	while(1){
		if(c>100){
			c=c*3;
		}else{
			c=30;	
		}
	}
	return 1;
	
}
