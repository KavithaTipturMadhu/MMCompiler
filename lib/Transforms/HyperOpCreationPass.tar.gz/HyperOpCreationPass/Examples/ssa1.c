#include <stdio.h>

int main()
{
	int c=0,d;
	while(1){
		if(c>100){
			c=c*3;
		}else{
			c=c*2;	
		}
	}

	for(c=0;c<10;c++){
		d=1;
		c=c*d;
	}
	return 1;
	
}
